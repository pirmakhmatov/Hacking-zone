Code Security Tools Suite - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Contains examples for integrating security tools into pipelines.