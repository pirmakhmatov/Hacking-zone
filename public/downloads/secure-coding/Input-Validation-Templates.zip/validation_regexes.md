Sample regexes and descriptions for common inputs (email, phone, uuid) - use carefully and test.
