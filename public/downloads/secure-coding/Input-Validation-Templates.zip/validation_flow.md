Input validation flow: whitelist -> sanitize -> encode -> log -> reject
