Reverse Engineering Tools Suite - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Contains notes and benign example scripts for lab use.