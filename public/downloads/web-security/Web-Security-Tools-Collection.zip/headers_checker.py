#!/usr/bin/env python3
"""headers_checker.py
Checks common security-related HTTP headers and reports missing ones.
Safe and read-only.
Usage: python3 headers_checker.py https://example.com
"""
import sys
import requests

SECURE_HEADERS = [
    'Content-Security-Policy',
    'Strict-Transport-Security',
    'X-Frame-Options',
    'X-Content-Type-Options',
    'Referrer-Policy',
    'Permissions-Policy'
]

def check(url):
    try:
        r = requests.get(url, timeout=6)
        print(f"Status: {r.status_code} | URL: {url}")
        for h in SECURE_HEADERS:
            print(f"{h}: {r.headers.get(h, '<missing>')}")
    except Exception as e:
        print('Error:', e)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python3 headers_checker.py <url>')
    else:
        check(sys.argv[1])
