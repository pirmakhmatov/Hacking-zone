#!/usr/bin/env python3
"""dependency_scanner.py
Simple scanner that parses requirements.txt or package.json (npm) to list dependencies.
It does not access the internet by default; it's for inventory and manual review.
Usage: python3 dependency_scanner.py <path-to-requirements.txt>
"""
import sys
from pathlib import Path

def scan_requirements(path):
    p = Path(path)
    if not p.exists():
        print('File not found:', path); return
    for line in p.read_text().splitlines():
        line=line.strip()
        if not line or line.startswith('#'): continue
        print('Dependency:', line)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python3 dependency_scanner.py <requirements.txt>')
    else:
        scan_requirements(sys.argv[1])
