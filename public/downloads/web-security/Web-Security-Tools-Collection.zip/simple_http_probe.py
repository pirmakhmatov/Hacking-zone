#!/usr/bin/env python3
"""simple_http_probe.py
Simple, educational script to probe HTTP status and extract page title.
Safe: performs only GET requests and prints results.
Usage: python3 simple_http_probe.py https://example.com
"""
import sys
import requests
from html import unescape
from bs4 import BeautifulSoup

def probe(url):
    try:
        r = requests.get(url, timeout=6)
        print(f"URL: {url} | Status: {r.status_code} | Content-Type: {r.headers.get('Content-Type')}")
        if 'text/html' in r.headers.get('Content-Type',''):
            soup = BeautifulSoup(r.text, 'html.parser')
            title = soup.title.string.strip() if soup.title else ''
            print(f"Title: {unescape(title)}")
    except Exception as e:
        print('Error:', e)

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python3 simple_http_probe.py <url>')
    else:
        probe(sys.argv[1])
