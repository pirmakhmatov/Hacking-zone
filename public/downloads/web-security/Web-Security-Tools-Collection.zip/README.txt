Web Security Tools Collection - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. These scripts are benign, read-only, and intended for learning,
inventory, and basic scanning in controlled environments. Do NOT use against systems you do not own
or have explicit permission to test. Unauthorized testing is illegal and unethical.

Contents:
- simple_http_probe.py       : Basic HTTP probe that fetches status and page title.
- headers_checker.py        : Reports missing common security headers.
- dependency_scanner.py     : Parses requirements.txt to list dependencies for manual review.

Notes:
- These tools are intentionally non-destructive. They demonstrate defensive reconnaissance and
  asset-inventory techniques that help secure applications.
- For hands-on vulnerable labs, use OWASP Juice Shop, Damn Vulnerable Web App (DVWA), or similar
  intentionally vulnerable environments.
