# log_parser.py - simple parser to extract ERROR/WARNING lines from logs
import sys
p=sys.argv[1] if len(sys.argv)>1 else '/var/log/syslog'
for line in open(p):
    if 'ERROR' in line or 'WARNING' in line:
        print(line.strip())
