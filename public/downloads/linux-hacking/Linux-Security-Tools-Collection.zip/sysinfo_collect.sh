#!/bin/bash
# Collect basic system info for triage (educational)
mkdir -p triage
uname -a > triage/uname.txt
ps aux --sort=-%mem | head -n 50 > triage/top_procs.txt
journalctl -n 200 > triage/recent_journal.txt
ls -la /etc > triage/etc_list.txt
echo 'Triage data collected.'
