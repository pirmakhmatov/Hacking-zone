Linux Security Tools Collection - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. These scripts are for triage, monitoring and defensive automation in lab environments.