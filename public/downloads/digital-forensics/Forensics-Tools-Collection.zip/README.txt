Forensics Tools Collection - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Contains notes and safe examples for forensic workflows.