# Forensic Report Template
- Case ID
- Evidence list
- Acquisition details
- Findings
- Recommendations
