# secure_random_example.py - use secrets module in Python
import secrets
print(secrets.token_hex(16))
