Cryptographic Implementation Templates - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Templates are for secure-by-design examples.