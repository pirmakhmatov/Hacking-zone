#!/bin/bash
# OpenSSL examples: generate key, CSR and self-signed cert (educational)
openssl genpkey -algorithm RSA -pkeyopt rsa_keygen_bits:2048 -out private.key
openssl req -new -key private.key -subj "/CN=example.local" -out request.csr
openssl x509 -req -in request.csr -signkey private.key -days 365 -out cert.pem
echo "Generated private.key, request.csr, cert.pem (educational)"