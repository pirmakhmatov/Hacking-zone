Cryptography Tools Collection - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Contains benign examples and notes for lab use.