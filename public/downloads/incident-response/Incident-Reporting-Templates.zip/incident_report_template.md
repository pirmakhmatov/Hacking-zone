# Incident Report Template
- Case ID
- Summary
- Timeline
- Impact
- Actions taken
- Recommendations
