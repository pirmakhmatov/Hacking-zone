Timeline workflow: collect logs, normalize timestamps, build event timeline, correlate with memory artifacts.
