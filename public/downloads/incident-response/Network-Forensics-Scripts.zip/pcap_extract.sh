#!/bin/bash
# Extract HTTP streams from pcap using tshark (example)
echo 'Use tshark -r file.pcap -Y http -w http_only.pcap'
