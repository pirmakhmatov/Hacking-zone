# steg_detect.sh - simple wrappers for steghide/binwalk (educational)
echo 'Use in lab only'