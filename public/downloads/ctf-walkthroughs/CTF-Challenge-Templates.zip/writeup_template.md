# Writeup Template
- Challenge:
- Approach:
- Commands:
- Final Flag:
