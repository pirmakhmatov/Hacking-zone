CTF Challenge & Writeup Templates - Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Use templates to structure challenges and writeups.