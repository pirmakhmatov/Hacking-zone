# Educational placeholder for Bluetooth scanning example
print('Example file - use in lab only')