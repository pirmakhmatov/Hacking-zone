# Educational placeholder for WiFi signal monitoring
print('Use platform tools like iwlist in lab')