# Educational password strength checker (entropy example)
print('Entropy example')