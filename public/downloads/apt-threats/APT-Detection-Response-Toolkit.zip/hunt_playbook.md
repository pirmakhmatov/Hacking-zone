# Hunt Playbook
- Objective: detect lateral movement
- Data sources: EDR, DNS logs, NetFlow
- Steps: ...

Attention: ONLY ACADEMIC PURPOSES.