APT Detection & Response Toolkit - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES.