Social Engineering Toolkit - educational
Creator: Hacking-zone community
Creator: Pirmaxmatov Og'abek

Attention: ONLY ACADEMIC PURPOSES. Contains templates and safe exercises for awareness programs.