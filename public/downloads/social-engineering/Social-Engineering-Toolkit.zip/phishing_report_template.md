# Phishing Report Template
- Received from:
- Subject:
- URL(s):
- Attachments:
- Action taken:
